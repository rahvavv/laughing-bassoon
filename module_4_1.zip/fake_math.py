def divide(first, second):
    if second == 0:
        return "Ошибка"
    else:
        return first / second
